document.addEventListener('DOMContentLoaded', function() {
    console.log('Modern Mobile Store theme loaded!');
});
