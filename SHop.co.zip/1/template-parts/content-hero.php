<?php
/**
 * Template: Hero Section
 * ACF Fields: hero_image (url), hero_heading, hero_subheading, hero_button_text, hero_button_link
 */

$hero_img   = get_field( 'hero_image' );
$heading    = get_field( 'hero_heading' )    ?: 'Dress Like Tomorrow.';
$subheading = get_field( 'hero_subheading' ) ?: 'Minimalist silhouettes crafted for the generation that doesn\'t follow trends — it sets them.';
$btn_text   = get_field( 'hero_button_text' ) ?: 'Shop the Drop';
$btn_link   = get_field( 'hero_button_link' );
?>

<section class="hero">
    <?php if ( $hero_img ) : ?>
    <img
        class="hero__image"
        src="<?php echo esc_url( $hero_img ); ?>"
        alt="<?php echo esc_attr( $heading ); ?>"
    >
    <?php endif; ?>
    <div class="hero__overlay"></div>
    <div class="hero__content">
        <div class="hero__tag">✦ New Season</div>
        <h1 class="hero__heading"><?php echo esc_html( $heading ); ?></h1>
        <p class="hero__subheading"><?php echo esc_html( $subheading ); ?></p>
        <?php if ( $btn_link ) : ?>
        <a href="<?php echo esc_url( $btn_link ); ?>" class="hero__cta">
            <?php echo esc_html( $btn_text ); ?>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
        </a>
        <?php endif; ?>
    </div>
</section>
