<?php
/**
 * Template part for displaying the Brand Story
 */
$story = get_field('brand_story');
if ($story) : ?>
    <section class="story" aria-labelledby="story-heading">
        <div class="container">
            <?php if ($story['tag']) : ?>
                <span class="story__tag"><?php echo esc_html($story['tag']); ?></span>
            <?php endif; ?>
            
            <h2 id="story-heading" class="story__heading"><?php echo wp_kses_post($story['heading']); ?></h2>
            <p class="story__text"><?php echo esc_html($story['text']); ?></p>
            
            <?php if ($story['cta_link']) : ?>
                <a href="<?php echo esc_url($story['cta_link']['url']); ?>" 
                   class="btn btn--outline"
                   target="<?php echo esc_attr($story['cta_link']['target'] ?: '_self'); ?>">
                    <?php echo esc_html($story['cta_link']['title']); ?>
                </a>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>
