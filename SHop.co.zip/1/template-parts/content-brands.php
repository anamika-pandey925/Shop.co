<?php
/**
 * Template: Brand Logos
 * ACF Fields: brand_logos (repeater) → logo (image url)
 */

if ( ! have_rows( 'brand_logos' ) ) return;
?>

<section class="brands">
    <div class="container">
        <p class="brands__label">Our Partners</p>
        <div class="brands__strip">
            <?php while ( have_rows( 'brand_logos' ) ) : the_row();
                $logo = get_sub_field( 'logo' );
                if ( ! $logo ) continue;
            ?>
            <div class="brands__item">
                <img src="<?php echo esc_url( $logo ); ?>" alt="Brand Logo" loading="lazy">
            </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>
