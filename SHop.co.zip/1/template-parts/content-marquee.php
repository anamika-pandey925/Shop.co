<?php
/**
 * Template part for displaying the scrolling marquee
 */
$marquee_items = get_field('marquee_items', 'option');
if ($marquee_items) : ?>
    <div class="marquee" role="marquee" aria-label="<?php echo esc_attr(get_field('marquee_aria_label', 'option') ?: 'Brand Announcements'); ?>">
        <div class="marquee__inner">
            <?php foreach ($marquee_items as $item) : ?>
                <div class="marquee__item"><?php echo esc_html($item['text']); ?></div>
            <?php endforeach; ?>
            
            <?php // Duplicate for continuous scroll ?>
            <?php foreach ($marquee_items as $item) : ?>
                <div class="marquee__item"><?php echo esc_html($item['text']); ?></div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>
