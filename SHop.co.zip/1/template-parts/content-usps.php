<?php
/**
 * Template part for displaying site USPs (Unique Selling Points)
 */
?>

<section class="usps">
    <div class="container usps__grid">
        <div class="usps__item">
            <div class="usps__icon">🚚</div>
            <div class="usps__content">
                <h4 class="usps__title">Free Shipping</h4>
                <p class="usps__text">On all orders over $99</p>
            </div>
        </div>
        <div class="usps__item">
            <div class="usps__icon">🔒</div>
            <div class="usps__content">
                <h4 class="usps__title">Secure Payment</h4>
                <p class="usps__text">100% encrypted checkout</p>
            </div>
        </div>
        <div class="usps__item">
            <div class="usps__icon">🔄</div>
            <div class="usps__content">
                <h4 class="usps__title">Easy Returns</h4>
                <p class="usps__text">30-day money back guarantee</p>
            </div>
        </div>
    </div>
</section>
