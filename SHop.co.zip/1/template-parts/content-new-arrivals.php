<?php
/**
 * Template: New Arrivals (WooCommerce)
 * Fetches 2 products from the 'new-arrivals' category.
 */

$query = new WP_Query( array(
    'post_type'      => 'product',
    'posts_per_page' => 2,
    'tax_query'      => array( array(
        'taxonomy' => 'product_cat',
        'field'    => 'slug',
        'terms'    => 'new-arrivals',
    ) ),
) );

if ( ! $query->have_posts() ) return;
?>

<section class="new-arrivals" id="new-arrivals">
    <div class="container">
        <div class="section-header">
            <h2 class="section-header__title">New Arrivals</h2>
            <a href="<?php echo esc_url( get_term_link( 'new-arrivals', 'product_cat' ) ); ?>" class="section-header__link">View All →</a>
        </div>
        <div class="products-grid">
            <?php while ( $query->have_posts() ) : $query->the_post();
                global $product; ?>
            <div class="product-card">
                <div class="product-card__image-wrap">
                    <?php echo $product->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy' ) ); ?>
                    <span class="product-card__badge">New</span>
                    <span class="product-card__wish" aria-label="Wishlist">🤍</span>
                </div>
                <div class="product-card__info">
                    <a href="<?php the_permalink(); ?>" style="text-decoration:none;color:inherit;">
                        <p class="product-card__name"><?php the_title(); ?></p>
                        <div class="product-card__footer">
                            <span class="product-card__price"><?php echo $product->get_price_html(); ?></span>
                            <button class="product-card__add" aria-label="Add to cart">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                            </button>
                        </div>
                    </a>
                </div>
            </div>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    </div>
</section>
