<?php
/**
 * Template part for displaying Customer Reviews
 */
$reviews_title = get_field('reviews_section_title') ?: 'What They\'re Saying';
$reviews = get_field('customer_reviews');

if ($reviews) : ?>
    <section id="reviews" class="reviews" aria-labelledby="reviews-heading">
        <div class="container">
            <h2 id="reviews-heading" class="section-title" style="text-align: center; margin-bottom: 40px;">
                <?php echo esc_html($reviews_title); ?>
            </h2>
            <div class="reviews__slider">
                <?php foreach ($reviews as $review) : ?>
                    <div class="review-card">
                        <div class="review-stars"><?php echo str_repeat('★', intval($review['rating'])); ?></div>
                        <p class="review-text"><?php echo esc_html($review['text']); ?></p>
                        <p class="review-user">— <?php echo esc_html($review['user_name']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
<?php endif; ?>
