<?php
/**
 * Template: Newsletter Section
 */
?>

<div class="newsletter">
    <p class="newsletter__eyebrow">Join the Circle</p>
    <h3 class="newsletter__heading">Get Early Access<br>to New Drops</h3>
    <p class="newsletter__sub">No spam, only the good stuff. Curated style, once a week.</p>
    <form class="newsletter__form" method="post">
        <?php if ( function_exists( 'wp_nonce_field' ) ) wp_nonce_field( 'mdrn_newsletter' ); ?>
        <input type="email" name="email" class="newsletter__input" placeholder="your@email.com" required>
        <button type="submit" class="newsletter__btn">Subscribe →</button>
    </form>
</div>
