<?php
/**
 * Template: Trust/USP Strip
 * Static — will show these three trust signals consistently.
 */
$usps = array(
    array( 'icon' => '🚀', 'label' => 'Free Ship',    'sub' => 'Orders ₹999+' ),
    array( 'icon' => '🔒', 'label' => 'Secure Pay',   'sub' => '256-bit SSL' ),
    array( 'icon' => '↩️', 'label' => 'Easy Returns', 'sub' => '30 Day Policy' ),
);
?>

<div class="trust">
    <?php foreach ( $usps as $usp ) : ?>
    <div class="trust__item">
        <span class="trust__icon"><?php echo $usp['icon']; ?></span>
        <span class="trust__label"><?php echo esc_html( $usp['label'] ); ?></span>
        <span class="trust__sub"><?php echo esc_html( $usp['sub'] ); ?></span>
    </div>
    <?php endforeach; ?>
</div>
