<?php
/**
 * Template part for displaying Featured Collections
 */
$collections = get_field('featured_collections');
if ($collections) : ?>
    <section id="collections" class="collections" aria-label="Featured Collections">
        <div class="container">
            <div class="collection-grid">
                <?php foreach ($collections as $collection) : 
                    $image = $collection['image'];
                    $link = $collection['link'];
                ?>
                    <a href="<?php echo esc_url($link['url']); ?>" class="collection-card" target="<?php echo esc_attr($link['target'] ?: '_self'); ?>">
                        <?php if ($image) : ?>
                            <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" loading="lazy">
                        <?php endif; ?>
                        <div class="collection-card__overlay"></div>
                        <div class="collection-card__content">
                            <h2 class="collection-card__title"><?php echo esc_html($collection['title']); ?></h2>
                            <span class="collection-card__link"><?php echo esc_html($collection['link_text'] ?: 'Explore Collection'); ?></span>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
<?php endif; ?>
