<?php
/**
 * Template part for displaying featured collections
 */
?>

<section class="featured">
    <div class="container">
        <h2 class="section-title">Collections</h2>
        <div class="featured-grid">
            <div class="featured-item" style="background-image: url('https://images.unsplash.com/photo-1511499767350-a1590fdb2817?auto=format&fit=crop&w=600&q=80');">
                <div class="featured-item__overlay">
                    <span class="featured-item__title">Eyewear</span>
                </div>
            </div>
            <div class="featured-item" style="background-image: url('https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80');">
                <div class="featured-item__overlay">
                    <span class="featured-item__title">Footwear</span>
                </div>
            </div>
        </div>
    </div>
</section>
