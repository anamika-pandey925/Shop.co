<?php
/**
 * ACF Field Registration — MDRN Store
 * All fields registered programmatically for full portability.
 */

if ( ! function_exists( 'acf_add_local_field_group' ) ) return;

// ============================================================
// GROUP 1: Store Settings (Options Page) — Announcement Bar
// ============================================================
acf_add_local_field_group( array(
    'key'    => 'group_store_settings',
    'title'  => '⚙️ Store Settings',
    'fields' => array(
        array(
            'key'          => 'field_announcement_text',
            'label'        => 'Announcement Bar Text',
            'name'         => 'announcement_bar_text',
            'type'         => 'text',
            'instructions' => 'Short message shown in the black bar at the top (e.g. "Free Shipping on orders ₹999+").',
            'required'     => 0,
        ),
        array(
            'key'          => 'field_marquee_items',
            'label'        => 'Marquee Items',
            'name'         => 'marquee_items',
            'type'         => 'repeater',
            'button_label' => '+ Add Text',
            'sub_fields'   => array(
                array(
                    'key'   => 'field_marquee_text',
                    'label' => 'Text',
                    'name'  => 'text',
                    'type'  => 'text',
                ),
            ),
        ),
        array(
            'key'          => 'field_category_chips',
            'label'        => 'Category Navigation Chips',
            'name'         => 'category_chips',
            'type'         => 'repeater',
            'button_label' => '+ Add Chip',
            'sub_fields'   => array(
                array(
                    'key'   => 'field_chip_label',
                    'label' => 'Label',
                    'name'  => 'label',
                    'type'  => 'text',
                ),
                array(
                    'key'   => 'field_chip_link',
                    'label' => 'Link',
                    'name'  => 'link',
                    'type'  => 'link',
                ),
                array(
                    'key'   => 'field_chip_active',
                    'label' => 'Is Active?',
                    'name'  => 'is_active',
                    'type'  => 'true_false',
                ),
            ),
        ),
        array(
            'key'          => 'field_footer_columns',
            'label'        => 'Footer Columns',
            'name'         => 'footer_columns',
            'type'         => 'repeater',
            'button_label' => '+ Add Column',
            'sub_fields'   => array(
                array(
                    'key'   => 'field_footer_col_title',
                    'label' => 'Column Title',
                    'name'  => 'title',
                    'type'  => 'text',
                ),
                array(
                    'key'   => 'field_footer_col_links',
                    'label' => 'Links',
                    'name'  => 'links',
                    'type'  => 'repeater',
                    'button_label' => '+ Add Link',
                    'sub_fields' => array(
                        array(
                            'key'   => 'field_footer_link',
                            'label' => 'Link',
                            'name'  => 'link',
                            'type'  => 'link',
                        ),
                    ),
                ),
            ),
        ),
        array(
            'key'          => 'field_social_links',
            'label'        => 'Social Links',
            'name'         => 'social_links',
            'type'         => 'repeater',
            'button_label' => '+ Add Platform',
            'sub_fields'   => array(
                array(
                    'key'   => 'field_social_platform',
                    'label' => 'Platform Name',
                    'name'  => 'platform',
                    'type'  => 'text',
                ),
                array(
                    'key'   => 'field_social_url',
                    'label' => 'URL',
                    'name'  => 'url',
                    'type'  => 'url',
                ),
            ),
        ),
        array(
            'key'          => 'field_payment_icons',
            'label'        => 'Payment Icons',
            'name'         => 'payment_icons',
            'type'         => 'repeater',
            'button_label' => '+ Add Payment Method',
            'sub_fields'   => array(
                array(
                    'key'   => 'field_payment_name',
                    'label' => 'Payment Name',
                    'name'  => 'name',
                    'type'  => 'text',
                ),
            ),
        ),
        array(
            'key'          => 'field_footer_copy',
            'label'        => 'Footer Copyright',
            'name'         => 'footer_copyright',
            'type'         => 'text',
            'placeholder'  => '© 2026 MDRN Store. All Rights Reserved.',
        ),
        array(
            'key'          => 'field_marquee_items',
            'label'        => 'Marquee Items',
            'name'         => 'marquee_items',
            'type'         => 'repeater',
            'button_label' => '+ Add Text',
            'sub_fields'   => array(
                array(
                    'key'   => 'field_marquee_text',
                    'label' => 'Text',
                    'name'  => 'text',
                    'type'  => 'text',
                ),
            ),
        ),
        array(
            'key'          => 'field_category_chips',
            'label'        => 'Category Navigation Chips',
            'name'         => 'category_chips',
            'type'         => 'repeater',
            'button_label' => '+ Add Chip',
            'sub_fields'   => array(
                array(
                    'key'   => 'field_chip_label',
                    'label' => 'Label',
                    'name'  => 'label',
                    'type'  => 'text',
                ),
                array(
                    'key'   => 'field_chip_link',
                    'label' => 'Link',
                    'name'  => 'link',
                    'type'  => 'link',
                ),
                array(
                    'key'   => 'field_chip_active',
                    'label' => 'Is Active?',
                    'name'  => 'is_active',
                    'type'  => 'true_false',
                ),
            ),
        ),
        array(
            'key'          => 'field_footer_columns',
            'label'        => 'Footer Columns',
            'name'         => 'footer_columns',
            'type'         => 'repeater',
            'button_label' => '+ Add Column',
            'sub_fields'   => array(
                array(
                    'key'   => 'field_footer_col_title',
                    'label' => 'Column Title',
                    'name'  => 'title',
                    'type'  => 'text',
                ),
                array(
                    'key'   => 'field_footer_col_links',
                    'label' => 'Links',
                    'name'  => 'links',
                    'type'  => 'repeater',
                    'button_label' => '+ Add Link',
                    'sub_fields' => array(
                        array(
                            'key'   => 'field_footer_link',
                            'label' => 'Link',
                            'name'  => 'link',
                            'type'  => 'link',
                        ),
                    ),
                ),
            ),
        ),
        array(
            'key'          => 'field_social_links',
            'label'        => 'Social Links',
            'name'         => 'social_links',
            'type'         => 'repeater',
            'button_label' => '+ Add Platform',
            'sub_fields'   => array(
                array(
                    'key'   => 'field_social_platform',
                    'label' => 'Platform Name',
                    'name'  => 'platform',
                    'type'  => 'text',
                ),
                array(
                    'key'   => 'field_social_url',
                    'label' => 'URL',
                    'name'  => 'url',
                    'type'  => 'url',
                ),
            ),
        ),
        array(
            'key'          => 'field_payment_icons',
            'label'        => 'Payment Icons',
            'name'         => 'payment_icons',
            'type'         => 'repeater',
            'button_label' => '+ Add Payment Method',
            'sub_fields'   => array(
                array(
                    'key'   => 'field_payment_name',
                    'label' => 'Payment Name',
                    'name'  => 'name',
                    'type'  => 'text',
                ),
            ),
        ),
        array(
            'key'          => 'field_footer_copy',
            'label'        => 'Footer Copyright',
            'name'         => 'footer_copyright',
            'type'         => 'text',
            'placeholder'  => '© 2026 MDRN Store. All Rights Reserved.',
        ),
    ),
    'location' => array( array( array(
        'param'    => 'options_page',
        'operator' => '==',
        'value'    => 'mdrn-store-settings',
    ) ) ),
) );

// ============================================================
// GROUP 2: Hero Section (Front Page)
// ============================================================
acf_add_local_field_group( array(
    'key'    => 'group_hero',
    'title'  => '🖼️ Hero Section',
    'fields' => array(
        array(
            'key'          => 'field_hero_image',
            'label'        => 'Background Image',
            'name'         => 'hero_image',
            'type'         => 'image',
            'return_format'=> 'url',
            'preview_size' => 'large',
            'instructions' => 'Upload a high-quality portrait or lifestyle photo (min 800×1000px).',
        ),
        array(
            'key'          => 'field_hero_heading',
            'label'        => 'Heading',
            'name'         => 'hero_heading',
            'type'         => 'text',
            'instructions' => 'Bold main heading. Example: "Dress Like Tomorrow."',
        ),
        array(
            'key'          => 'field_hero_subheading',
            'label'        => 'Subheading',
            'name'         => 'hero_subheading',
            'type'         => 'textarea',
            'rows'         => 2,
            'instructions' => 'One or two short sentences below the heading.',
        ),
        array(
            'key'          => 'field_hero_button_text',
            'label'        => 'Button Text',
            'name'         => 'hero_button_text',
            'type'         => 'text',
            'default_value'=> 'Shop the Drop',
        ),
        array(
            'key'          => 'field_hero_button_link',
            'label'        => 'Button Link (URL)',
            'name'         => 'hero_button_link',
            'type'         => 'url',
            'instructions' => 'Where the button takes the user. Paste a link or leave blank.',
        ),
    ),
    'location' => array( array( array(
        'param'    => 'page_type',
        'operator' => '==',
        'value'    => 'front_page',
    ) ) ),
) );

// ============================================================
// GROUP 3: Brand Logos (Front Page)
// ============================================================
acf_add_local_field_group( array(
    'key'    => 'group_brand_logos',
    'title'  => '🏷️ Brand Logos',
    'fields' => array(
        array(
            'key'         => 'field_brand_logos_repeater',
            'label'       => 'Brands',
            'name'        => 'brand_logos',
            'type'        => 'repeater',
            'layout'      => 'table',
            'button_label'=> '+ Add Brand',
            'instructions'=> 'Add partner brand logos. Upload SVG or PNG with transparent background.',
            'sub_fields'  => array(
                array(
                    'key'           => 'field_brand_logo_image',
                    'label'         => 'Logo Image',
                    'name'          => 'logo',
                    'type'          => 'image',
                    'return_format' => 'url',
                    'preview_size'  => 'thumbnail',
                ),
            ),
        ),
    ),
    'location' => array( array( array(
        'param'    => 'page_type',
        'operator' => '==',
        'value'    => 'front_page',
    ) ) ),
) );
